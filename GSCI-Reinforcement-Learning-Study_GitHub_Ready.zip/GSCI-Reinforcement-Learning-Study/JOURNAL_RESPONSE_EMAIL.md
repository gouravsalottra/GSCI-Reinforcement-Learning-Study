# Reply to Risks Editorial Office

**Subject:** Working Data/Code Repository for Risks 14(9), 188

Dear Editorial Office,

Thank you for bringing this issue to our attention. We have verified and populated the repository referenced in the Data Availability Statement. The working public URL is:

<https://github.com/gouravsalottra/GSCI-Reinforcement-Learning-Study>

The repository now contains the complete analysis and model code, the ten frozen PPO model files, frozen configurations, derived strategy-level outputs, inference and robustness results, validation tests, metadata, all publication figures, environment specifications, and a repository-wide SHA-256 manifest.

Because the primary security-level total-return and Treasury-bill inputs were obtained from CRSP through WRDS and are subject to institutional licensing restrictions, we have not redistributed the underlying CRSP files. To make the analysis fully reconstructable for authorized users, the repository contains an output-stripped WRDS notebook with the exact CRSP tables, fields, permanent security identifiers, date ranges, and deterministic transformations. The repository’s `DATA_AVAILABILITY.md` explains this division clearly and gives the public-source provenance for the frozen-policy temporal extension.

We have also verified that the repository is publicly accessible without authentication and that its integrity and output-contract checks pass.

We apologize for the temporary empty repository and appreciate the opportunity to correct the published record promptly. The URL printed in the article is accurate and can remain unchanged.

Kind regards,

Gourav Salotra  
Eugene Pinsky

Article: Salotra, G.; Pinsky, E. “Do Reinforcement Learning Agents Improve Commodity Sector Rotation? Walk-Forward Evidence from Expert Selection, Strong Benchmarks, and a Frozen-Policy Temporal Extension.” *Risks* 2026, 14(9), 188. <https://doi.org/10.3390/risks14090188>
