# Emergency Publication Instructions

The Data Availability Statement already points to:

<https://github.com/gouravsalottra/GSCI-Reinforcement-Learning-Study>

The repository owner is `gouravsalottra` (two consecutive `t` characters after `salo`). Publish this package to that exact repository so the published URL does not need to change.

## Option A: authorize the connected account, then let Codex publish

The currently connected GitHub account is `gouravsalotra` (one `t`) and presently has read-only access to the repository. From the owner account `gouravsalottra`:

1. Open the repository.
2. Select **Settings → Collaborators → Add people**.
3. Add `gouravsalotra` with write access.
4. Accept the invitation while signed in as `gouravsalotra`.
5. Return to ChatGPT and say: `GitHub write access fixed—publish it.`

## Option B: push from a computer authenticated as the repository owner

Extract the release ZIP, open Terminal in the extracted parent directory, and run:

```bash
cd GSCI-Reinforcement-Learning-Study
git init -b main
git add -- .gitignore CITATION.cff CODEBOOK.md DATA_AVAILABILITY.md LICENSE README.md REPRODUCIBILITY.md PUBLISH_TO_GITHUB.md JOURNAL_RESPONSE_EMAIL.md SHA256SUMS.txt requirements.txt requirements-ppo-frozen.txt config data figures metadata models notebooks outputs paper scripts src tests
git commit -m "Publish replication package for Risks 14(9), 188"
git remote add origin https://github.com/gouravsalottra/GSCI-Reinforcement-Learning-Study.git
git push -u origin main
```

GitHub may ask you to authenticate in the browser. Do not paste a password or access token into source files or chat.

## Mandatory public check

After pushing, open this URL in a private/incognito browser window:

<https://github.com/gouravsalottra/GSCI-Reinforcement-Learning-Study>

Confirm that the README renders, `src/`, `outputs/`, `models/`, `figures/`, and `notebooks/` are visible, and `models/ppo_fixed_results.zip` downloads successfully. Only then send the journal reply in `JOURNAL_RESPONSE_EMAIL.md`.
